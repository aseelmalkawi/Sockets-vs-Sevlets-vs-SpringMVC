package webapp.servlets;

import webapp.services.AnalyticsService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(urlPatterns = "/analyse.do")
public class AnalyticsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.getRequestDispatcher("/WEB-INF/views/welcome.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        String course = request.getParameter("c");
        String name = LoginServlet.name;
        AnalyticsService as = new AnalyticsService();

        try {
            String result = null;
            if (as.isInCourse(name, Integer.parseInt(course))) {
                result = String.valueOf(AnalyticsService.courseInformation(name, Integer.parseInt(course)));
            }
            else {
                result = "You're not registered int his course!";
            }

            request.setAttribute("result", result);
            request.getRequestDispatcher("/WEB-INF/views/welcome.jsp").forward(request, response);
        } catch (SQLException | ServletException | IOException e) {
            e.printStackTrace();
        }
    }
}