package webapp.models;

import java.io.Serializable;

public class StudentsGrades implements Serializable {
    private String courseName;
    private int grade;

    @Override
    public String toString() {
        return "Course name = " + courseName + ", grade = " + grade + "</BR>";
    }

    public StudentsGrades(String courseName, int grade) {
        this.courseName = courseName;
        this.grade = grade;
    }

    public String getCourseName() {
        return courseName;
    }

    public int getGrade() {
        return grade;
    }
}