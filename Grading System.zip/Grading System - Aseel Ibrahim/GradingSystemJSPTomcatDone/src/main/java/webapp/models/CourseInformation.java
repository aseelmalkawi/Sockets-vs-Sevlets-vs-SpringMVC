package webapp.models;

public class CourseInformation {
    private String mark, max, min, avg;

    public CourseInformation() {

    }

    @Override
    public String toString() {
        return "<strong>Course Information:</strong>" +
                "</BR>Grade: " + mark +
                "</BR>Max: " + max +
                "</BR>Min: " + min +
                "</BR>Avg: " + avg;
    }
    public void setMark(String mark) {
        this.mark = mark;
    }

    public void setMax(String max) {
        this.max = max;
    }

    public void setMin(String min) {
        this.min = min;
    }
    public void setAvg(String avg) {
        this.avg = avg;
    }
}
