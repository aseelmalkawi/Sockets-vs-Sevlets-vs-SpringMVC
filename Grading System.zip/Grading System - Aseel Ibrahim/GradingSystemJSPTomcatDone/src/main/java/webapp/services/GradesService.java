package webapp.services;

import webapp.models.StudentsGrades;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;

public class GradesService implements Serializable {

 public static ArrayList<StudentsGrades> displayGrades(String std_id) throws SQLException {
   ArrayList<StudentsGrades> resultSetList = new ArrayList<>();
   Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3307/school","root", "aseel2000");
   PreparedStatement pStmt = conn.prepareCall("select CID, Mark from RegistersIn where Username = ?");
   pStmt.setString(1, std_id);
   ResultSet resultSet = pStmt.executeQuery();
   while (resultSet.next()) {
    resultSetList.add(new StudentsGrades(resultSet.getString("CID"),
            resultSet.getInt("Mark")));
  }
  return resultSetList;
 }
}