package webapp.services;

import java.sql.*;

public class LoginService {
	Connection connection;
	PreparedStatement st;
	ResultSet rs;

	public boolean validateUser(String username, String password) throws SQLException {
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3307/school","root", "aseel2000");

		st = connection.prepareStatement("Select username, password from Account where Username=? and Password=?");

		st.setString(1, username);
		st.setString(2, password);
		rs = st.executeQuery();
		return rs.next();
	}
}