package webapp.services;

import com.mysql.cj.jdbc.MysqlDataSource;
import webapp.models.CourseInformation;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AnalyticsService {
    private static DataSource dataSource;

    public AnalyticsService(){
        try{
            dataSource = getDataSource();
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }
    private DataSource getDataSource() throws SQLException {
        MysqlDataSource ds = new MysqlDataSource();
        ds.setServerName("localhost");
        ds.setDatabaseName("school");
        ds.setUser("root");
        ds.setPort(3307);
        ds.setPassword("aseel2000");
        ds.setUseSSL(false);
        ds.setAllowPublicKeyRetrieval(true);

        return ds;
    }

    public boolean isInCourse(String std_id , int curse_id) throws SQLException {
        try(Connection conn = dataSource.getConnection()){
            PreparedStatement pStmt = conn.prepareCall("select * from RegistersIn where  Username = ? and CID = ?");
            pStmt.setString(1, String.valueOf(std_id));
            pStmt.setString(2, String.valueOf(curse_id));
            ResultSet res = pStmt.executeQuery();

            return res.next();
        }
    }
    public static ArrayList<CourseInformation> courseInformation(String std_id , int course_id) throws SQLException {
        ArrayList<CourseInformation> resultSetList = new ArrayList<>();
        try (Connection conn = dataSource.getConnection()) {
            PreparedStatement pStmt = conn.prepareStatement("select Mark from RegistersIn where Username = ? and CID = ?");
            PreparedStatement pStmt2 = conn.prepareStatement("Select max(Mark), min(Mark), avg(Mark) from RegistersIn where CID = ?");
            pStmt.setString(1, std_id);
            pStmt.setString(2, String.valueOf(course_id));
            pStmt2.setString(1, String.valueOf(course_id));

            ResultSet resultSet = pStmt.executeQuery();

            CourseInformation course = new CourseInformation();
            while (resultSet.next()) {
                course.setMark(resultSet.getString("Mark"));
            }

            resultSet = pStmt2.executeQuery();

            while (resultSet.next()) {
                course.setMax(resultSet.getString("max(Mark)"));
                course.setMin(resultSet.getString("min(Mark)"));
                course.setAvg(resultSet.getString("avg(Mark)"));
            }

            resultSetList.add(course);
        }
        return resultSetList;
    }
}
