import java.io.Serializable;

public class StudentGrades implements Serializable {
 private String courseName;
 private int grade;

 public StudentGrades(String courseName, int grade) {
  this.courseName = courseName;
  this.grade = grade;
 }

 public String getCourseName() {
  return courseName;
 }

 public int getGrade() {
  return grade;
 }
}