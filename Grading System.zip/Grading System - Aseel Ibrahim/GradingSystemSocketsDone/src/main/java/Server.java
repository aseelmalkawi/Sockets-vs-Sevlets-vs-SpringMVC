import java.io.DataInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;

public class Server {
    int clientNumber = 0;

    public void startServer() {
        new Thread(() -> {
            clientNumber++;
            try {
                ServerSocket serverSocket = new ServerSocket(8000);
                System.out.println("starting thread for client " + clientNumber);
                while (true) {
                    Socket socket = serverSocket.accept();

                    System.out.println("client connected");

                    new Thread(new HandleAClient(socket, clientNumber)).start();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    public static void main(String[] args) {
        new Server().startServer();
    }
}
class HandleAClient implements  Runnable {
    private Socket socket;
    private int clientNumber;

    public HandleAClient(Socket socket, int clientNumber) {
        this.socket = socket;
        this.clientNumber = clientNumber;
    }

    @Override
    public void run() {
        try {
            DataInputStream inputFromClient = new DataInputStream(socket.getInputStream());
            ObjectOutputStream outputToClient = new ObjectOutputStream(socket.getOutputStream());

            String ID = inputFromClient.readUTF();
            String password = inputFromClient.readUTF();
            DAO dao = new DAO();
            boolean login = dao.logIn(ID, password);
            if (login) {
                outputToClient.writeBoolean(true);
                outputToClient.flush();
                System.out.println("Student: " + ID + " login");
                while (login) {
                    int option = inputFromClient.readInt();
                    switch (option) {
                        case 1 -> {
                            ArrayList<StudentGrades> Grades = dao.displayGrades(ID);
                            outputToClient.writeObject(Grades);
                            outputToClient.flush();
                        }
                        case 2 -> {
                            int curs_id = inputFromClient.readInt();
                            ArrayList<CourseInformation> information = dao.courseInformation(ID, curs_id);
                            outputToClient.writeObject(information);
                            outputToClient.flush();
                        }
                        case 3 -> {
                            login = inputFromClient.readBoolean();
                            System.out.println("Student number: " + ID + " logged out");
                        }
                    }
                }
            } else outputToClient.writeBoolean(false);
            outputToClient.flush();
        } catch (IOException ex) {
            System.out.println("Error I/O problem");
            System.out.println(ex.getMessage());
            System.exit(0);
        } catch (SQLException ex) {
            System.out.println("Error communicating with database");
            System.out.println(ex.getMessage());
            System.exit(0);
        }
    }
}