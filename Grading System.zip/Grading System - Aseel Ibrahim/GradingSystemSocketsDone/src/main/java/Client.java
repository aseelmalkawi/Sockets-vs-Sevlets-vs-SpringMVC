import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class Client {
    DataOutputStream toServer = null;
    ObjectInputStream fromServer = null;
    String ID;
    String password;
    Scanner scan = new Scanner(System.in);

    public void startClient() throws IOException {
            // Create a socket to connect to the server
            Socket socket = new Socket("localhost", 8000);
            // Create an input stream to receive data from the server
            fromServer = new ObjectInputStream(socket.getInputStream());
            // Create an output stream to send data to the server
            toServer = new DataOutputStream(socket.getOutputStream());

        try {
            System.out.println("Please enter your username: ");
            ID = scan.next();
            System.out.println("Enter your password: ");
            password = scan.next();
            toServer.writeUTF(ID);
            toServer.writeUTF(password);
            toServer.flush();
            boolean login = fromServer.readBoolean();

            if (login) {
                System.out.println("Welcome " + ID);
                do {
                    System.out.println("Chose one of the options:");
                    System.out.println("1. Display grades");
                    System.out.println("2. Statistics About Particular Course");
                    System.out.println("3. Exit");

                    int option = scan.nextInt();

                    try {
                        switch (option) {
                            case 1 -> {
                                toServer.writeInt(option);
                                Object objectResultSet = fromServer.readObject();
                                ArrayList<StudentGrades> records = (ArrayList<StudentGrades>) objectResultSet;
                                for (StudentGrades record : records)
                                    System.out.println(record.getCourseName() + " " + record.getGrade());
                            }
                            case 2 -> {
                                toServer.writeInt(option);
                                System.out.println("Enter course ID ");
                                int course_id = scan.nextInt();
                                toServer.writeInt(course_id);
                                Object objectResultSet = fromServer.readObject();
                                ArrayList<CourseInformation> information = (ArrayList<CourseInformation>) objectResultSet;
                                for (CourseInformation record : information) {
                                    System.out.println("Grade = " + record.getMark());
                                    System.out.println("Max = " + record.getMax());
                                    System.out.println("Min = " + record.getMin());
                                    System.out.println("Average = " + record.getAvg());
                                }
                            }
                            case 3 -> {
                                System.out.println("Exiting... ");
                                toServer.writeInt(3);
                                toServer.writeBoolean(false);
                                System.exit(0);
                            }
                            default -> System.out.println("I don't understand");
                        }

                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                } while (true);

            } else {
                System.out.println("invalid id or password. Try again!");
                System.exit(0);
            }

          /* Object, object = fromServer.readObject();
           int lod = Integer.parseInt((String) object);
           ArrayList<String> titleList = (ArrayList<String>) object;
           for(String str : titleList)
               System.out.println(str);*/


        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    public static void main(String[] args) throws IOException {
        new Client().startClient();
    }
}