import com.mysql.cj.jdbc.MysqlDataSource;
import javax.sql.*;
import java.sql.*;
import java.util.ArrayList;

public class DAO {
    private DataSource dataSource;
    public DAO() {
        try {
            dataSource = getDataSource();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    private DataSource getDataSource() throws SQLException {
        MysqlDataSource ds = new MysqlDataSource();
        ds.setServerName("localhost");
        ds.setDatabaseName("school");
        ds.setUser("root");
        ds.setPort(3307);
        ds.setPassword("aseel2000");
        ds.setUseSSL(false);
        ds.setAllowPublicKeyRetrieval(true);

        return ds;
    }

    public ArrayList<StudentGrades> displayGrades(String std_id) throws SQLException {
        ArrayList<StudentGrades> resultSetList = new ArrayList<>();
        try (Connection conn = dataSource.getConnection()) {
            PreparedStatement pStmt = conn.prepareCall("select CID, Mark from RegistersIn where Username = ?");
            pStmt.setString(1, std_id);
            ResultSet resultSet = pStmt.executeQuery();
            while (resultSet.next()) {
                resultSetList.add(new StudentGrades(resultSet.getString("CID"),
                        resultSet.getInt("Mark")));
            }
        }
        return resultSetList;
    }

    public ArrayList<CourseInformation> courseInformation(String std_id, int course_id) throws SQLException {
        ArrayList<CourseInformation> resultSetList = new ArrayList<>();
        try (Connection conn = dataSource.getConnection()) {
            PreparedStatement pStmt = conn.prepareStatement("select Mark from RegistersIn where Username = ? and CID = ?");
            PreparedStatement pStmt2 = conn.prepareStatement("Select max(Mark), min(Mark), avg(Mark) from RegistersIn where CID = ?");
            pStmt.setString(1, std_id);
            pStmt.setString(2, String.valueOf(course_id));
            pStmt2.setString(1, String.valueOf(course_id));

            ResultSet resultSet = pStmt.executeQuery();

            CourseInformation course = new CourseInformation();
            while (resultSet.next()) {
                course.setMark(Integer.parseInt(resultSet.getString("Mark")));
            }

            resultSet = pStmt2.executeQuery();

            while (resultSet.next()) {
                course.setMax(Integer.parseInt(resultSet.getString("max(Mark)")));
                course.setMin(Integer.parseInt(resultSet.getString("min(Mark)")));
                course.setAvg(Double.parseDouble(resultSet.getString("avg(Mark)")));
            }

            resultSetList.add(course);
        }
        return resultSetList;
    }

    public boolean logIn(String std_id, String pass) throws SQLException {
        try(Connection conn  = dataSource.getConnection()){
            PreparedStatement pStmt = conn.prepareStatement("select username, password from Account where  Username = ? and Password = ?");
            pStmt.setString(1, std_id);
            pStmt.setString(2, pass);
            ResultSet res = pStmt.executeQuery();

            return res.next();
        }
    }
}