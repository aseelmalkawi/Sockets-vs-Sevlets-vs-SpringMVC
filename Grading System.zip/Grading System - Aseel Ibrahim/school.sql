drop table `RegistersIn`;
drop table `Account`;
drop table `Course`;

CREATE TABLE `Account` (
  `Username` varchar(10),
  `Password` varchar(50),
  PRIMARY KEY (`Username`)
);

CREATE TABLE `Course` (
  `CID` varchar(10),
  `CName` varchar(20),
  PRIMARY KEY (`CID`)
);

CREATE TABLE `RegistersIn` (
  `Username` varchar(10),
  `CID` varchar(10),
  `Mark` int,
  PRIMARY KEY (`Username`,`CID`),
  FOREIGN KEY (`Username`) REFERENCES `Account`(`Username`) ON DELETE CASCADE,
  FOREIGN KEY (`CID`) REFERENCES `Course`(`CID`) ON DELETE CASCADE
);

insert into Account values ('Aseel', 'aseel123');
insert into Account values ('Ahmad', 'Ahmad123');
insert into Account values ('Ali', 'Ali123');

insert into Course values ('1', 'Java');
insert into Course values ('2', 'Network');
insert into Course values ('3', 'Database');

insert into RegistersIn values ('Aseel', '1', '90');
insert into RegistersIn values ('Ahmad', '1', '88');
insert into RegistersIn values ('Ahmad', '2', '78');
insert into RegistersIn values ('Ali', '1', '67');
insert into RegistersIn values ('Ali', '2', '91');
insert into RegistersIn values ('Ali', '3', '50');
